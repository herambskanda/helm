---
name: decision-log
description: How to write a decision artifact in Helm (decision.md) so that anyone can see later what was decided, why, and what else was weighed. Read it before making or changing a decision.
---

# Decision log

A decision is one Markdown file, `decision.md`, in the artifact's folder. The person reads it in the
**Decision** face and changes the words in the **Text** face.

## What goes in it, in this order
1. `# <the decision, as a sentence>`: “We ship guest checkout before saved cards.”
2. `**Decided** <date> · **by** <who> · **status** Proposed | Decided | Replaced`
3. `## Why`: two to five lines. Link the evidence (an insight, a number) by its artifact title.
4. `## Options we weighed`: one bullet each, with what it would have cost or risked.
5. `## Look again when`: the thing that would make us change our minds (a number, a date).

## Rules
- One decision per artifact. If it splits, make two.
- Never rewrite a decided one. When it changes, make a new decision and set the old one's status to
  “Replaced by <new title>”.
- Keep it under a page.
