# The decision, as one sentence

**Decided** – · **by** – · **status** Proposed

## Why
- 

## Options we weighed
- 

## Look again when
- 
