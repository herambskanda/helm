# Interview notes: first-time shoppers

Six short calls, 22–25 September.

## What repeated
- **Accounts get in the way** (4 of 6). “I just wanted the lamp.” (L., 23 Sep)
- **Delivery cost shows up too late** (3 of 6). “Why is it more now?” (A., 24 Sep)

## What surprised us
- Nobody minded giving an email address. They minded a password.

## What we still don't know
- Whether returning shoppers would miss saved cards.
