# Guest checkout

**As a** first-time shopper **I want to** pay without making an account **so that** I can finish
my order in under a minute.

## Context
4 of 6 shoppers we spoke to gave up at “Create an account”. One said: “I just wanted the lamp.”

## Acceptance criteria
- [ ] A shopper can pay with only an email address and a card.
- [ ] After paying, they're offered an account with one tap, never before.
- [ ] The order confirmation reaches the email they gave within a minute.
