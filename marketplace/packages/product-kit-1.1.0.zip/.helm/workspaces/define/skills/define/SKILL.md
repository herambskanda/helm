---
name: define
description: The brief for a Define workspace, where what was learned becomes user stories and specs people can build from. Read it when working in Define.
---

# Define

Turn what we learned into stories engineering can build from.

- Start from the evidence: the findings, quotes and numbers in the project (often in Discover).
  Every story says what it rests on.
- One story per need. Write it with the User story workbench; keep longer thinking (a spec, a
  decision, open questions) in a Document.
- A story is ready when its statement is one sentence, its context cites evidence, and it has at
  least three acceptance criteria a tester can check.
- Ask the person before marking anything agreed; they decide what's ready.
