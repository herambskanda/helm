---
name: discover
description: The brief for a Discover workspace, where research is gathered and made sense of (notes, findings, data, sources). Read it when working in Discover.
---

# Discover

Find out what is really going on before deciding what to do.

- Keep sources as they came: PDFs, screenshots and exports go in as they are.
- Write notes and findings as Documents; keep numbers in Tables.
- **Tie every claim to a quote or a number,** and say where it came from (who, when, which file).
- A finding needs more than one source. Count (“4 of 6 shoppers”) rather than generalise.
- Say plainly what we still don't know.
