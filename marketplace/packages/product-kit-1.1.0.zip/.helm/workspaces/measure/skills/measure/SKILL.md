---
name: measure
description: The brief for a Measure workspace, where the project's numbers are worked out in notebooks and explained plainly. Read it when working in Measure.
---

# Measure

Work out what the numbers say, and say plainly what moved and why.

- Work in a Notebook: the data inside the artifact, one step per cell, results as tables and
  charts. Keep a finished list of numbers as a Table, and the write-up as a Document.
- Every number says where it came from and which dates it covers.
- Lead with the answer (“the biggest drop is details to payment: 37% leave there”), then how it
  was worked out.
- Don't claim a cause the data doesn't show. Say what would confirm it.
