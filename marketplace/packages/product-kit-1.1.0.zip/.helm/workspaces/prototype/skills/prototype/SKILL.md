---
name: prototype
description: The brief for a Prototype workspace, where ideas become clickable web pages and sketches to try with people. Read it when working in Prototype.
---

# Prototype

Show the idea as something people can click, and try it with them.

- Sketch first (an Image, in SVG) when the shape isn't settled; build a Web page when it is.
- A prototype works on a phone (390 px wide) as well as on a desktop, with no internet.
- Realistic content, never lorem ipsum. Every button does something or says it isn't built.
- Keep one prototype per idea, so each can be tested on its own.
