---
name: pdf
description: "How to handle a PDF artifact in Helm (document.pdf, kept as it came): reports, papers, exports. Read it before adding, making, replacing or answering questions about a PDF."
---

# PDF

A PDF artifact holds one file, `document.pdf`. The person sees its title, pages and size in the
**PDF** face.

## Bringing one in
Usually a PDF comes from somewhere: `new_artifact {workbench: "pdf", title: "Checkout study"}`,
copy the file over the empty `document.pdf` in its folder, then `open_artifact`.

## Making one
Only make a PDF when a real one can be made; never leave `document.pdf` empty or write fake bytes.
1. Write the source first (plain text or HTML) in a scratch folder outside the project.
2. Print it to `document.pdf` in the artifact's folder with a tool on this computer: write the page as HTML and
   print it with the browser that is there, headless (Chrome or Edge: `--headless --print-to-pdf=<folder>/document.pdf page.html`,
   using the browser's own path on this system), or for plain text a print filter if the system has one (`cupsfilter notes.txt > document.pdf`
   on a Mac or Linux). If none works, say so and offer a Document instead.
3. `open_artifact` with its id.

## Working with one
- Don't change a PDF someone brought in. To make a changed version, make a new one and say so.
- When asked about it, extract its text and answer with page numbers.
- A PDF you make has a Title (the HTML `<title>`), so the face shows it.
