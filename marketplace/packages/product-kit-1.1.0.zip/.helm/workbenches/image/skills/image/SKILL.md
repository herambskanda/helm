---
name: image
description: "How to make an image artifact in Helm (one picture: image.svg for sketches, diagrams and wireframes you draw; image.png or image.jpg for screenshots and photos). Read it before making or replacing an image."
---

# Image

An image artifact holds one picture. The person sees it in the **Image** face, fitted to the space
or zoomed in.

## Making one
1. `new_artifact {workbench: "image", title: "Checkout flow sketch"}`. It answers the folder, which
   starts with an **empty `image.png`**.
2. Write the picture:
   - **A sketch, wireframe or diagram you draw: write `image.svg`, then delete the empty
     `image.png`** (while `image.png` is there, it's the one shown, and it's empty).
   - A screenshot or photo: put it in place of `image.png` (or write `image.jpg` and delete
     `image.png`). `image.gif` and `image.webp` work the same way.
3. `open_artifact` with its id.

## An SVG the face draws well
```svg
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="500" viewBox="0 0 800 500">
  <title>Checkout flow: basket, details, payment, done</title>
  <rect width="800" height="500" fill="#fbfbf8"/>
  <rect x="40" y="200" width="150" height="80" rx="10" fill="#fff" stroke="#15191c" stroke-width="2"/>
  <text x="115" y="246" font-family="-apple-system, Helvetica, Arial, sans-serif" font-size="18" text-anchor="middle">Basket</text>
  …
</svg>
```
- `xmlns`, a `width`, a `height` and a `viewBox`, and a `<title>` saying what it shows.
- Everything in the one file: no scripts, links, outside images or web fonts (they don't load).
- A background rect, so it reads in light and dark themes; text 14 px or larger.

## A good image
- Shows one thing, and its title says what.
- Screenshots and photos no bigger than they need to be (under 2 MB).
