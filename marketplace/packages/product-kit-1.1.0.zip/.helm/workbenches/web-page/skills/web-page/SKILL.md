---
name: web-page
description: How to make a web page artifact in Helm (index.html plus its own CSS, JavaScript and images, no internet) for clickable prototypes, landing pages, UI samples and small tools. Read it before making or changing a web page.
---

# Web page

A web page is `index.html` in the artifact's folder, with any `style.css`, `app.js` or images beside
it. The person sees it working in the **Web page** face (as a Desktop, Tablet, Phone or Small phone,
scripts running, buttons clicking) and reads the code in the **Text** face.

## Making one
1. `new_artifact {workbench: "web-page", title: "Sign-up page"}`. It answers the folder.
2. Replace `index.html` with the whole page (it starts as a placeholder). A small page is one file
   with a `<style>` and a `<script>`; a bigger one has `style.css` and `app.js` beside it, linked with
   relative paths (`<link rel="stylesheet" href="style.css">`, `<script src="app.js"></script>`).
3. `open_artifact` with its id.

## Several pages
A clickable prototype of a flow is several pages: `index.html` is the first; put the others in `site/`
(`site/details.html`, `site/payment.html`) or beside it, and link them with plain relative links
(`<a href="site/details.html">`, and `<a href="../index.html">` back). The face has a page picker and
follows those links. Share one `style.css` between them.

## The preview server
When the workspace starts the **Preview server** (a service: it runs while the workspace is open),
the pages are also served at an address on this computer (`http://127.0.0.1:<port>/`), to open in a
real browser. Nothing changes in how you write them.

## The file
```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign-up page</title>
<style>
  body { margin: 0; font: 16px/1.5 -apple-system, "Helvetica Neue", Arial, sans-serif; }
  main { max-width: 420px; margin: 0 auto; padding: 24px 16px; }
</style>
</head>
<body>
<main>…</main>
<script>/* the page's behaviour */</script>
</body>
</html>
```

## What the preview allows
- **No internet:** no CDNs, web fonts, trackers or outside APIs; they don't load. System fonts, your
  own CSS and JavaScript, images as files in the folder or inline SVG.
- No frames, no pop-up windows, no forms that post anywhere. Handle a form's submit in JavaScript
  and show the result on the page.

## A good page
- Works at 360 px wide (a small phone), on a tablet and on a desktop.
- For a prototype or a UI sample: realistic made-up content (names, prices, dates), never lorem
  ipsum; every button either does something or says plainly that it isn't part of the prototype.
- Looks finished: a clear hierarchy, consistent spacing, one accent colour, readable contrast.
- Plain, readable code over clever code: the person may read it in the Text face.
