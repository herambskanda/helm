---
name: notebook
description: What a good notebook artifact is in Helm (notebook.ipynb plus the data it reads, kept in the artifact's folder). Read it before making or changing a notebook.
---

# Notebook

A notebook artifact is one Jupyter notebook, `notebook.ipynb`, and the files it reads, kept beside
it (usually in `data/`). The person reads it, edits it and runs it in the Notebook view. The format
and how cells run are the Notebook runner's (see its skill).

A new notebook starts as a worked example: the checkout funnel, from `data/checkout_events.csv`.
Replace its cells and data with the real question.

## A good notebook
- It answers one question, named in its first Markdown cell and in the artifact's title.
- Its data lives inside the artifact (`data/…`), so it runs the same for everyone. Say in the
  first cell where the data came from and which dates it covers.
- One step per cell, each after a sentence that says what it does.
- Results as `helm.table` or `helm.chart`, and a last cell that says the answer in plain words.
- It runs from top to bottom with **Run all** after a **Restart**.
