---
name: user-story
description: "How to write a user story in Helm (story.md): a one-sentence statement, the context with its evidence, and acceptance criteria as a checklist. Read it before writing, reviewing or changing a story."
---

# User story

A story is one file, `story.md`, in the artifact's folder. The person sees it as a **Story** card
(statement, context, numbered criteria they can tick) and as **Text**. The exact format is in the
story-card skill; in short:

```markdown
# Guest checkout

As a first-time shopper, I want to pay without making an account, so that I can finish buying before I lose interest.

Four of six shoppers in last week's interviews stopped at “Create an account”; two said they'd have left the site. Account creation is the biggest drop-off in the funnel (41%).

## Acceptance criteria

- [ ] “Continue as guest” sits beside “Sign in” on the first checkout step.
- [ ] A guest pays with only an email address, a delivery address and a card.
- [ ] After paying, a guest is offered (not made) to save their details as an account.
```
- **The first paragraph that isn't a heading is the statement; the second is the context.** One
  paragraph each, a blank line between them.
- The criteria go under a heading named exactly `Acceptance criteria`, one `- [ ]` line each. Don't
  number them (the card does). Anything after them (`## Notes` …) is kept but not shown.

## Making one
1. `new_artifact {workbench: "user-story", title: "Guest checkout"}` (stories usually live in the
   Define workspace; Helm adds it if the project doesn't have one).
2. Write the whole of `story.md` in one go (it starts as `# Untitled` and an empty criteria list).
3. `open_artifact` with its id.

## A good story
- **One person, one goal, one reason**, in one sentence: “As a …, I want …, so that …”.
- **The context says why now**, with the evidence: a quote and who said it, or a number and where it
  came from.
- **Three to six acceptance criteria**, each testable with a yes or no by someone who didn't write
  it. Say what the person sees or can do, not how it's built.
- Small enough to build in a week or two; if not, split it into stories that each stand alone.
- Only tick (`- [x]`) a criterion when it's true of what's built; the person usually does this.

Write in plain sentences: no Markdown bold (`**`) or italics inside the story; the story card shows plain words.

## Its flow and its evidence
A story also has two files the person sees as their own tabs:
- `flow.json` (**Flow**): the steps a person goes through for this story, with what changes at each
  (the flow-view skill has the format). Draw it when the story changes a journey.
- `evidence.json` (**Evidence**): the insights, quotes and numbers behind the story, each pointing at
  the artifact it came from (the evidence-board skill has the format). The context paragraph
  summarises it; the cards let anyone check it.
