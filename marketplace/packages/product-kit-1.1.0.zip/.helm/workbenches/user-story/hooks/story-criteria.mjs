// A story needs acceptance criteria: at least three `- [ ]` items under "## Acceptance criteria".
// Helm runs it when a story changes, with what happened as JSON on stdin.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

let input = '';
for await (const chunk of process.stdin) input += chunk;
const { artifact } = JSON.parse(input || '{}');
let text = '';
try { text = readFileSync(join(artifact.folder, 'story.md'), 'utf8'); } catch {}
const part = text.split(/^## Acceptance criteria[ \t]*$/m)[1] || '';
const count = (part.split(/^## /m)[0].match(/^\s*- \[[ xX]\]/gm) || []).length;
if (count >= 3) { console.log(count + ' criteria.'); process.exit(0); }
// A story nobody has written yet (only the starting headings) isn't a failure: say nothing alarming.
if (!text.replace(/^#+.*$/gm, '').trim()) { console.log('Not written yet.'); process.exit(0); }
console.error(`“${artifact.title}” has ${count} acceptance ${count === 1 ? 'criterion' : 'criteria'}; it needs at least 3.`);
process.exit(2);
