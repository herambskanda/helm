---
description: Split a story that does too much into two
argument-hint: "[what to split on]"
---

Split this story into two smaller stories that each stand alone, each with its own statement and at
least three acceptance criteria. $ARGUMENTS
