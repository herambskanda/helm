---
name: Story from insight
description: Turns an agreed finding into a user story with its evidence, checks it, then waits for you.
home: workspace:define
workspace: define
reads: [doc]
writes: [story]
steps:
  - who: main
    does: Read the finding and the notes it came from
  - who: writer
    does: Draft the story, its acceptance criteria and its evidence
  - check: A story needs acceptance criteria
    does: Every story has at least one acceptance criterion
  - who: you
    does: Review the story
    choices: [Approve, Ask for changes]
---
Write stories the way the User story instructions say.
