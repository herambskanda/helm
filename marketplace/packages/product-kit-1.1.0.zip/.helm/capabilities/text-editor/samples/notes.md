# Checkout interviews: first notes

Six shoppers, 40 minutes each, over two days. Everyone had abandoned a cart on our site in the last
month.

## What we heard
- Four of six stopped at “Create an account”. Two said they’d come back “later” and didn’t.
- Three typed their card number twice because the page reloaded after a coupon.
- Shipping cost appeared only on the last step. One shopper called it “a trick”.

## To follow up
1. Pull the funnel numbers for the account step (Priya).
2. Check how many orders use a coupon at all.
3. Ask support for the “where’s my order” tickets from guest-like accounts.

> “I just wanted the shoes. I didn’t want a relationship.” (Shopper 4)
