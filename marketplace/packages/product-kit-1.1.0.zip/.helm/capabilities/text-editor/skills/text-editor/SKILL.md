---
name: text-editor
description: The plain text of an artifact's file (Markdown, plain text, HTML, CSV, JSON), shown to the person in a simple editor that saves as they type. Use it when the person wants to see or change the words exactly as they are stored.
---

# Text editor

The person sees the file exactly as it is on disk, in a plain editor. They can type into it, and it
saves about half a second after they stop.

## Working with it
- **Files are the API.** To change what the person sees, edit the file itself. The editor redraws
  when the file changes.
- Keep the file's own format. Don't add front matter, comments or markers the file didn't have.
- If the person is typing in the file when you change it, your change waits beside theirs as a
  suggestion: they choose Accept (yours) or Dismiss (theirs). So make one clear, whole change at a
  time rather than many small ones.
- Write UTF-8 with `\n` line endings, and end the file with a newline.
