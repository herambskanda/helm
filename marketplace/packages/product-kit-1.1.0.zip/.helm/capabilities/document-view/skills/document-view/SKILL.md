---
name: document-view
description: "Shows a Markdown file to the person as a finished, readable document (headings, lists, task lists, tables, quotes, code). Use it for anything written to be read: notes, summaries, specs, briefs."
---

# Document view

The person reads the file here as a finished document. They don't edit in this view; they edit in
the Text view beside it, or ask you.

## Writing for it
- Plain Markdown (CommonMark with tables, task lists `- [ ]` and `~~strike~~`). Raw HTML is shown as
  text, not drawn, so don't use it.
- Start with one `# Title`, then short sections under `##`. Keep paragraphs short.
- Tables need a header row and a `|---|` line under it. Columns of numbers are aligned right.
- Images aren't drawn yet (they show as a small “Image: …” label); link to the file instead.
- Front matter between `---` lines at the very top is kept but not shown.
- **Files are the API.** Edit the file; the view redraws by itself.
