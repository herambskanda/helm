# Why shoppers leave checkout

Six interviews and four weeks of funnel data point the same way: **the account step** loses more
shoppers than any other, and most of them never come back.

## What we found
1. **The account wall.** Four of six shoppers stopped at “Create an account”. Two said they’d come
   back later; neither did.
2. **Typing a card on a phone.** Three shoppers typed their card number twice after a coupon
   reloaded the page.
3. **Shipping shown late.** Shipping cost appears only on the last step. One shopper called it
   “a trick”.

> “I just wanted the shoes. I didn’t want a relationship.” (Shopper 4, 12:40)

## The numbers

| Step | Shoppers | Left here |
|---|---:|---:|
| Cart | 12,480 | 18% |
| Account | 10,234 | 41% |
| Delivery | 6,038 | 9% |
| Payment | 5,495 | 12% |
| Placed | 4,836 | |

## What’s next
- [x] Share the findings with engineering
- [ ] Write a story for each finding, in Define
- [ ] Test a guest checkout with five shoppers

Data from the `checkout_funnel` dashboard, 1–28 September. See the *interview notes* for every quote.
