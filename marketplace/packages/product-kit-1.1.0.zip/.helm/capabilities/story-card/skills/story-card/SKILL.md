---
name: story-card
description: Shows a user story (story.md) as a card with its statement, context and numbered acceptance criteria the person can tick and edit. Use it to read or change a story's statement, context or criteria, and to mark criteria as met.
---

# Story card

The person sees the story as a card: the statement large, the context under it, then the
acceptance criteria as a numbered list with a tick box each (“2 of 4 met”). They can click any line
to change it, tick a criterion, or add one. Their changes are written straight back to `story.md`.

## The story.md format
```markdown
# Guest checkout                       ← optional title (the artifact's title is shown instead)

As a first-time shopper, I want to pay without making an account, so that I can finish buying
before I lose interest.                ← first paragraph: the statement

Four of six shoppers stopped at “Create an account” …   ← second paragraph: the context

## Acceptance criteria

- [x] “Continue as guest” sits beside “Sign in” on the first checkout step.
- [ ] A guest pays with only an email address, a delivery address and a card.

## Notes                               ← anything else: kept exactly as it is, not shown
```
- **Statement:** the first paragraph that isn't a heading. One sentence: who, what, why.
- **Context:** the second paragraph. What we know and why it matters, with the evidence.
- **Acceptance criteria:** the list under a heading named exactly “Acceptance criteria” (any level
  from `##`). Each item is `- [ ] …` (not met) or `- [x] …` (met), one line each. Numbers are shown
  by the card; don't write them.
- Everything else (a title, more sections, notes, front matter) is kept as it is and not shown.

## Working with it
- **Files are the API.** Edit `story.md`; the card redraws by itself.
- Keep each criterion testable: something a tester can check with a yes or no.
- Only tick a criterion (`[x]`) when it's true of what's built; the person usually does this.
- If the person is editing the card when you change the file, your change waits as a suggestion
  (Accept or Dismiss), so make one whole change at a time.
