# Guest checkout

As a first-time shopper, I want to pay without making an account, so that I can finish buying before I lose interest.

Four of six shoppers we interviewed stopped at “Create an account”, and the funnel agrees: 41% of shoppers leave at the account step, more than at any other. Two said they would come back later; neither did.

## Acceptance criteria

- [x] “Continue as guest” sits beside “Sign in” on the first checkout step.
- [ ] A guest pays with only an email address, a delivery address and a card.
- [ ] After paying, a guest can make an account with one tap, keeping the order.
- [ ] The order confirmation email reaches a guest within a minute.

## Notes

Evidence: interviews 2, 3, 4 and 6; the checkout funnel for 1–28 September.
