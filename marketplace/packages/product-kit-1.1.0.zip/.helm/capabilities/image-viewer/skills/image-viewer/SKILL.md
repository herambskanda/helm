---
name: image-viewer
description: Shows an image file (PNG, JPEG, GIF, WebP, SVG) to the person, fitted to the space or zoomed. Use it for sketches, screenshots, diagrams, photos and charts kept as artifacts.
---

# Image

The person sees the image fitted to the space, and can zoom to 100% or closer. They don't edit it
here; they ask you, or replace the file.

## Working with it
- **Files are the API.** To change the picture, write the image file. The view redraws by itself.
- For a sketch or diagram you draw yourself, write **SVG**: it's text, so it's easy to change a piece
  at a time, and it stays sharp at any zoom. Give it a `width`, a `height` and a `viewBox`, and a
  `<title>` saying what it shows.
- An SVG here is drawn as a picture: scripts, links and outside images or fonts inside it don't load.
  Keep everything in the one file.
- For a photo or a screenshot, keep the original format (PNG or JPEG).
- An empty file shows as nothing. In an Image artifact, `image.png` wins over `image.svg` while it's
  there, so when you write `image.svg`, delete the empty `image.png` that it started with.
