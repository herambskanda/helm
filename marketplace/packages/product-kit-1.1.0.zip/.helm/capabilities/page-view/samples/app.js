document.getElementById('signin').addEventListener('click', () => {
  document.getElementById('note').textContent = 'Signing in isn’t part of this prototype: try Continue.';
});
