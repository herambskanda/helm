---
name: page-view
description: Shows an HTML page (with its own CSS, JavaScript and images) to the person, working, at desktop or phone width. Use it for clickable prototypes, landing pages, and small tools made as one page.
---

# Web page

The person sees the page working: its scripts run and its buttons click. They can switch between
Desktop and Phone width. It's a preview: the page can't reach the internet.

## Making a page for it
- The page is `index.html` in the artifact. Other files beside it (`style.css`, `app.js`,
  `img/logo.png`) are fine: stylesheets, scripts and images it names with a relative path are put
  into the page when it's shown.
- **No internet:** nothing loads from outside (no CDNs, web fonts, APIs or analytics). Write the CSS
  and JavaScript yourself, keep them small, and use system fonts.
- No frames inside the page, no pop-up windows, no forms that post anywhere; the preview blocks them.
  For a form, handle the submit in JavaScript and show the result on the page.
- Make it work at 390 px wide as well as on a desktop: people check both.
- **Files are the API.** Edit the files; the preview reloads by itself.
