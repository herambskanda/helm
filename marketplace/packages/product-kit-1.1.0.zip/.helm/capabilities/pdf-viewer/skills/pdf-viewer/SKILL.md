---
name: pdf-viewer
description: Shows a PDF file to the person as a card with its title, number of pages and size, and a way to open it in Preview. Use it for reports, papers, contracts and exports kept as artifacts.
---

# PDF

The person sees the PDF's title, how many pages it has and its size. Helm can't draw a PDF's pages
inside the window yet, so they read it in Preview.

## Working with it
- The PDF is read-only here. To change it, make a new PDF from its source (for example, a Markdown
  document) and replace the file.
- When the person asks about a PDF, read the file yourself (extract its text) and answer; quote the
  page number.
- Set the PDF's Title in its document information when you make one: it's what the card shows.
