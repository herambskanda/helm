---
name: evidence-board
description: Shows the evidence behind a piece of work (evidence.json) as cards - insights, quotes and numbers - each saying where it came from and pointing at that artifact. Use it to gather or change the evidence for a user story or a decision, and to read which card the person pointed at.
---

# Evidence board

The person sees one card per piece of evidence: what kind it is and where it's from (“Quote · Ana ·
14:32”), a big number when there is one, the words (quotes in italics), and “Open …” to go to the
artifact it came from. They can point at a card (its locator is `card-<n>`, counting from 1).

## The evidence.json format
```json
{
  "shape": "evidence",
  "cards": [
    {"kind": "Insight", "from": "Discover", "says": "4 of 6 interviewees abandoned at account creation",
     "points_at": "discover/account-wall"},
    {"kind": "Quote", "from": "Ana · 14:32", "says": "“I just wanted the shoes, not another password.”",
     "points_at": "discover/ana", "at": "14:32"},
    {"kind": "Number", "from": "Measure", "big": "37.1%", "says": "of sessions are lost between details and payment",
     "points_at": "measure/checkout-funnel"}
  ]
}
```
- `kind`: `Insight`, `Quote`, `Number` or `Note`. `from`: where it came from, in the person's words
  (the workspace, or who said it and when). `says`: the evidence in one sentence; a quote in
  curly quotes, word for word. `big`: the number, for a `Number` card.
- `points_at`: the artifact it came from, as its folder from the project root; `at`: where in it
  (a time in a recording, a row). `title`: that artifact's name, when its folder name doesn't read
  well.
- Only real evidence: read the artifact before you quote it or take a number from it. Three to six
  cards read best; put the strongest first.

## Working with it
- **The file is the API.** Write `evidence.json` with your file tools; the face redraws.
- When the person points at a card, change or remove that card and keep the others' order.
