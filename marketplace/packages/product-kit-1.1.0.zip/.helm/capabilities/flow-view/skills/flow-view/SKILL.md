---
name: flow-view
description: Shows a flow (flow.json) as numbered steps joined by lines, each with a note on what changes there. Use it to draw or change the steps a person goes through (a checkout, a sign-up, a process), and to read which step the person pointed at.
---

# Flow diagram

The person sees the steps in order, each a box with its number, its name and a short note, joined by
a line. A step that goes somewhere other than the next one says “then …”. They can point at a step
(its locator is `step-<id>`).

## The flow.json format
```json
{
  "shape": "flow",
  "steps": [
    {"id": "cart", "label": "Cart", "note": "Shipping cost shown"},
    {"id": "details", "label": "Details", "note": "Guest by default"},
    {"id": "payment", "label": "Payment", "note": "Card or Apple Pay"},
    {"id": "done", "label": "Done", "note": "Offer to save an account"}
  ],
  "edges": [["cart", "details"], ["details", "payment"], ["payment", "done"]]
}
```
- `steps` in the order a person meets them. `id`: short, lowercase, unique, and kept when you
  change the label (the person's points use it). `label`: one or two words. `note`: what happens
  or changes at that step, in one short sentence; leave it empty for “No change from today”.
- `edges`: `[from, to]` pairs of ids. Left out, each step leads to the next. Add an edge for a
  branch (`["details", "sign-in"]`); the step then says “then Sign in or Payment”.
- Keep it to the steps that matter: four to eight read best.

## Working with it
- **The file is the API.** Write `flow.json` with your file tools; the face redraws.
- When the person points at a step, change that step's `label` or `note`, keeping its `id`.
