---
name: pdf-pages
description: Shows a PDF's real pages to the person, with page thumbnails, zoom and selectable text. Use it for reports, papers, contracts, exports and anything kept as a PDF.
---

# PDF pages

The person reads the PDF itself: every page drawn as it prints, thumbnails down the side (hidden
in a narrow pane), previous/next and a page counter, zoom in and out or fit to the width. They can
select and copy the text of pages that have text (scanned pages are pictures and have none).

## Working with it
- The PDF is read-only here. To change it, make a new PDF from its source (for example, a
  Markdown document) and replace the file; the pages redraw.
- When the person asks about the PDF, read the file yourself (extract its text) and answer;
  quote the page number (“page 3 says …”).
- Set the PDF's Title in its document information when you make one: it's shown above the pages.
- A PDF locked with a password can't be shown; say so and ask the person for an unlocked copy.
