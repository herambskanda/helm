---
name: table-editor
description: Shows a CSV file as a table the person can edit cell by cell and add rows to. Use it for lists, trackers, small data sets and anything with rows and columns.
---

# Table

The person sees the CSV as a table with a header row. They click a cell to change it and can add
rows. Their changes are written straight back to the file.

## The format
- Plain CSV (RFC 4180): commas between fields; a field with a comma, a quote or a line break is
  wrapped in double quotes, and a quote inside it is written twice (`""`).
- **The first row is the header.** Give every column a short, plain name.
- One kind of thing per column. Columns whose cells are all numbers are aligned right, so write
  numbers plainly (`12480`, `41%`, `£84.00`), without words around them.
- UTF-8, `\n` line endings, a newline at the end. Keep the file's own line endings if it has others.
- **Files are the API.** Edit the file; the table redraws. For a big change, rewrite the whole file
  once rather than many small edits.
- **Rows are real or marked.** A new table starts with its header and no rows, or with one or two rows
  marked as examples (`Example …` in the first cell). Never fill it with invented entries that look
  like the person's own (names, dates, amounts); sample data only when they ask for it.
