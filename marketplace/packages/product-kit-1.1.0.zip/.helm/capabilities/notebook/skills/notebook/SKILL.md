---
name: notebook
description: "Shows a Jupyter notebook (.ipynb) as Python and text cells the person can edit and run, with each cell's output under it. Use it for working through data step by step: loading a file, counting, comparing, and showing the result as a table or a chart."
---

# Notebook

The person sees the notebook's cells in order: Python code cells and Markdown text cells. They
press **Run** on a cell (or **Run all**, or Shift-Enter) and its output appears under it. Cells
share one Python that keeps its variables until the person presses **Restart**, so a later cell
can use what an earlier one made.

## The format
- The file is a standard Jupyter notebook (nbformat 4.5), so it opens in Jupyter and VS Code too.
  Keep `cells`, `metadata` (with `kernelspec` python3) and `nbformat`; give each cell an `id`.
- A cell's `source` is a list of lines, each ending in `\n` except the last.
- Outputs are saved in the file. When you change a code cell, clear its `outputs` and set
  `execution_count` to `null`: the old output no longer matches the code. The person runs it.
- **Files are the API.** Edit the `.ipynb`; the notebook redraws. For a big change, rewrite the
  whole file once.

## How cells run
- Python 3, in **the notebook's own folder**: `open("data/events.csv")` means the file inside
  this artifact. `helm.project` is the project's folder (a `pathlib.Path`).
- Only the standard library is sure to be there. Don't assume pandas, numpy or matplotlib; if a
  cell needs one, say so and let the person install it.
- Each cell has a time limit (2 minutes). Keep cells short; one step each.
- `helm` is already imported in every cell:
  - `helm.table(rows, columns=None, title=None)`: rows as a list of dicts, a list of lists, or a
    dict. Shows a table.
  - `helm.chart(data, kind="bar"|"line", x=None, y=None, title=None)`: `data` as `{label: number}`,
    a list of `(label, number)`, or a list of dicts with `x=` the label column and `y=` a column or
    a list of columns (one series each). Shows a chart.
  - `helm.read_csv(path)`: a CSV as a list of dicts, with numbers as numbers.
  These show their output straight away. The last line of a cell, if it's a value, is shown too.
- The person may not know Python. Start each notebook with a short Markdown cell that says what it
  answers, put a sentence of Markdown before each step, and end with a cell that prints the
  answer in plain words.

## Running a notebook yourself
You can't press Run. To check a result, run the same code with Python in a terminal from the
notebook's folder, or ask the person to press **Run all** and read the outputs saved in the file.
