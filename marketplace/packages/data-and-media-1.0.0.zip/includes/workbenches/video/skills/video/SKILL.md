---
name: video
description: What a good video artifact is in Helm - a video file (video.mp4, .webm or .mov) with its timed transcript (transcript.vtt). Use it when adding, transcribing or quoting recorded calls, usability sessions and demos.
---

# Video

A video artifact holds one video and, once it's been transcribed, its transcript:

- `video.mp4` (or `video.webm`, `video.mov`): the video, kept as it came.
- `transcript.vtt`: WebVTT, one cue per spoken turn, `<v Name>` for who speaks, real timings.

## A good one
- The title says what and when: “Usability session 3, 22 Sep”.
- The transcript names each speaker the same way throughout.
- Quotes and moments taken from it keep their time (`1:04`), so anyone can play the moment.
- Nothing personal leaves the project unless the person asks.
