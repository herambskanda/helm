---
name: dashboard
description: What a good dashboard artifact is in Helm - dashboard.json (tiles and charts, drawn by the Dashboard view capability) over its data in data.csv. Use it when making or updating metrics, funnels and results for the person.
---

# Dashboard

A dashboard artifact holds:

- `dashboard.json`: what the person sees - the title, a few tiles and the charts, in order. Its
  format is in the Dashboard view's skill (`dashboard-view`).
- `data.csv`: the rows the charts draw from (`"data": "data.csv"`), shown as a table in the Data
  tab where the person can correct a number.

## A good one
- It answers one question, named in its title (“Checkout”, “Signups this week”).
- Four tiles or fewer, each a number someone would act on; `tone` only on the one to watch.
- Every chart has a plain title, and at most one colour to draw the eye (`focus`).
- `source` and `updated` say where the numbers come from and when.
- When the numbers come from a notebook or a script, update `data.csv` from it and leave
  `dashboard.json` alone unless the charts themselves change.
