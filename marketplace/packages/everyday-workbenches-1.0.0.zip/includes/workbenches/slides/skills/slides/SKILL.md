---
name: slides
description: What a good slide deck artifact is in Helm - one PowerPoint file (slides.pptx) that opens in Keynote and PowerPoint and reads well in Helm's Slides viewer. Use it when making, reviewing or summarising presentations.
---

# Slides

A slide deck artifact holds one file, `slides.pptx`, that opens in Keynote, PowerPoint and Google
Slides as well as in Helm.

## A good one
- One idea per slide, said in its title (“People leave between details and payment”), so the
  titles alone tell the story.
- Few words on a slide; what the speaker says goes in the speaker notes.
- Real text boxes, not text inside pictures.
- Numbers behind a chart are also in the notes (Helm doesn't draw charts or tables yet).
- 16:9 unless the person asks otherwise.
