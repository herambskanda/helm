---
name: research
description: The brief for a Research workspace, where interviews are recorded, transcribed and made sense of. Read it when working in Research.
---

# Research

Hear people out before deciding anything.

- Every interview is a **Recording** (the audio and its transcript). Notes and findings are
  **Documents**; counts and answers are **Tables**.
- Quote people word for word, with who said it and when. Don't tidy their words.
- Never put an interviewee's full name in a finding. Say “a shopper” or use their first initial.
- A finding needs at least two interviews behind it. Count (“4 of 6”) rather than generalise.
- Once a week, the Researcher writes what repeated and what surprised us (the Weekly synthesis).
