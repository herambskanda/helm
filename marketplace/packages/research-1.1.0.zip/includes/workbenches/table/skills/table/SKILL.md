---
name: table
description: How to make a table artifact in Helm (table.csv, a header row and one kind of fact per column) for lists, trackers and small data sets. Read it before making or changing a table.
---

# Table

A table is one CSV file, `table.csv`, in the artifact's folder. The person edits it cell by cell in
the **Table** face, or as text in the **Text** face.

## Making one
1. `new_artifact {workbench: "table", title: "Checkout drop-off by step"}`. It answers the folder.
2. Write the whole of `table.csv` in one go (it starts with a `Name,Notes` header you replace). Its
   rows are only what the person told you or what you read in a real source (see **Rows that are
   real** below).
3. `open_artifact` with its id.

## The file
```csv
Step,Shoppers,Dropped,Drop-off,Note
Basket,1200,144,12%,
Account,1056,433,41%,"Most said ""I just want to pay"""
Payment,623,56,9%,
```
- Plain CSV (RFC 4180): commas between fields; a field with a comma, a quote or a line break is
  wrapped in double quotes, and a quote inside it is written twice (`""`).
- **The first row is the header**: short, plain column names. Every row has as many fields as the
  header.
- UTF-8, `\n` line endings, a newline at the end.

## A good table
- One row per thing, one kind of fact per column.
- Numbers written plainly so they line up and can be added up (`12480`, `41%`, `£84.00`), with no
  words around them; put units in the column name if they'd repeat.
- Where the data came from goes in the title or a Note column, never in stray rows.

## Rows that are real
- A new table for the person's own things (orders, customers, a tracker) **starts empty**: the header
  and no rows, and you tell them it's ready for their first one. Or give it one or two rows **clearly
  marked as examples**: `Example` at the start of the first cell, or a Note column that says
  “example, remove it”, and say so in your reply.
- **Never invent entries that look real**: no made-up names, dates, amounts or orders the person could
  take for theirs. Rows come from what the person told you, a file they gave you, or a source you
  read, and you say which.
- Only when the person asks for sample or practice data, fill it (5–15 rows, never `foo`/`bar`), and
  put “sample” in the title.
