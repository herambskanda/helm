---
name: recording
description: What a good recording artifact is in Helm - an audio file (recording.mp3, .m4a, .wav or .ogg) with its timed transcript (transcript.vtt). Use it when adding, transcribing or quoting interviews, calls and voice notes.
---

# Recording

A recording artifact holds one recording and, once it's been transcribed, its transcript:

- `recording.mp3` (or `recording.m4a`, `recording.wav`, `recording.ogg`): the audio, kept as it came.
- `transcript.vtt`: WebVTT, one cue per spoken turn, `<v Name>` for who speaks, real timings.

## A good one
- The title says who and when: “Ana, 20 Sep”.
- The transcript names each speaker the same way throughout (“Ana”, “Interviewer”).
- Quotes taken from it keep their time (`0:12`), so anyone can play the moment.
- Nothing personal leaves the project: don't paste a recording's words anywhere outside it
  unless the person asks.
- `highlights.json` (the **Highlights** tab): the quotes that matter, each with its time and a tag
  (the highlights skill has the format). Add them once the transcript is there.
