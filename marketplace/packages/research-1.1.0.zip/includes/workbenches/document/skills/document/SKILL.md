---
name: document
description: How to write a document artifact in Helm (doc.md, Markdown) for notes, summaries, specs, briefs and findings. Read it before making or changing a document.
---

# Document

A document is one Markdown file, `doc.md`, in the artifact's folder. The person reads it in the
**Document** face (drawn as a finished page) and changes the words in the **Text** face.

## Making one
1. `new_artifact {workbench: "document", title: "Checkout research summary"}` (add `workspace` if
   you know where it belongs). It answers the folder.
2. Write the whole of `doc.md` in that folder in one go (it starts as `# Untitled`).
3. `open_artifact` with its id, so the person sees it.

## The file
```markdown
# Checkout research summary

For the checkout team: what six shoppers told us, and what we'd change first.

## What we found
- **Four of six** stopped at “Create an account” (interviews 1, 2, 4, 6).
- Card entry took 94 seconds on average (session recordings, 12–18 Sept).

## What we'd do next
1. Let people pay as a guest.
2. …

| Step | Drop-off |
|---|---:|
| Basket | 12% |
| Account | 41% |
```
- One `# Title` at the top, the same as the artifact's title; then short sections under `##`.
- CommonMark with tables, task lists (`- [ ]`) and `~~strike~~`. **No raw HTML** (it shows as text)
  and no images (they show as a small label; link to the file instead).
- Front matter between `---` lines at the very top is kept but not shown.

## A good document
- **One job.** The line under the title says what it's for and who it's for.
- Plain words, short paragraphs; lists for steps and options, tables for numbers.
- Every claim that matters says where it came from (an interview, a number, a file).
- Ends with what happens next, if anything does.
- When changing one, keep the person's own words unless they ask you to rewrite them.
