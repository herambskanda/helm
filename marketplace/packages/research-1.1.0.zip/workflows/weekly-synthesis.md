---
name: Weekly synthesis
description: Looks across the week's interviews and writes what repeated, then waits for you.
home: workspace:research
workspace: research
reads: [recording, doc]
writes: [doc]
steps:
  - who: interview-analyst
    does: Pull the quotes out of any transcript that has none yet
  - who: researcher
    does: Write what repeated, what surprised us and what we still don't know
  - who: you
    does: Read the synthesis
    choices: [Looks right, Ask for changes]
---
Quote people word for word and never name them in full.
