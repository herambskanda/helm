---
name: checklist-view
description: Shows a Markdown file's task list (- [ ] and - [x] lines) as a checklist the person ticks, with a count of what's done. Use it for launch lists, packing lists and anything done step by step.
---

# Checklist view

The person sees every `- [ ]` and `- [x]` line in the file as a box they can tick, grouped under the
`##` heading above it, with “5 of 12 done” at the top. Ticking writes `[x]` back into the file.

## Writing for it
- One task per line: `- [ ] Book the venue`. Keep each under a line; put detail on the next,
  indented line (it's shown small under the task).
- Group tasks under `## Headings`. Lines that aren't tasks are kept and not shown.
- To mark a task done, change `[ ]` to `[x]`. Don't delete done tasks; people like to see them.
- **Files are the API.** Edit the file; the view redraws by itself.
