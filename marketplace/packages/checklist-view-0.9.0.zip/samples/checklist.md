# Launch checklist

## Before
- [x] Write the release notes
- [x] Check the checkout on a phone
- [ ] Tell support what's changing
  Send them the release notes and the three questions people will ask.

## On the day
- [ ] Turn guest checkout on for everyone
- [ ] Watch the funnel for an hour

## After
- [ ] Share the first week's numbers
