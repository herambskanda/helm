---
name: Launch emails
description: Drafts three launch emails from a story and its release notes, checks them, then waits for you.
home: project
reads: [story, doc]
writes: [doc]
steps:
  - who: main
    does: Read the story and the release notes, and list the three things people will care about
  - who: main
    does: Draft three emails (customers, support, the team) as one document
  - check: Each email says what changes, for whom, and when
    does: Every email names the change, who it's for and the date
  - who: you
    does: Read the drafts
    choices: [Send-ready, Ask for changes]
---
Short sentences. No exclamation marks. Say the date as a day and a month.
